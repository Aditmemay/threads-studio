# Floating Tools 1.0 (Android)

Ứng dụng tiện ích cửa sổ nổi gồm đồng hồ, ghi chú nhanh và máy tính cơ bản. Ứng dụng không có chức năng xúc xắc, dự đoán hay cá cược.

## Tính năng
- Bong bóng `FT` nổi trên ứng dụng khác, có thể kéo thả.
- Chạm bong bóng để mở/ẩn bảng tiện ích.
- Đồng hồ số cập nhật theo thời gian thực.
- Ghi chú nhanh, lưu cục bộ trên thiết bị.
- Máy tính hỗ trợ `+`, `-`, `*`, `/`, dấu ngoặc và số thập phân.
- Dịch vụ hiển thị thông báo khi cửa sổ nổi đang hoạt động.

## Yêu cầu
- Android 8.0 (API 26) trở lên.
- Quyền **Hiển thị trên ứng dụng khác**.
- Project dùng Android Gradle Plugin 8.9.1, Kotlin 2.0.21, compile/target SDK 35.

## Tạo APK bằng GitHub Actions (có thể thao tác bằng trình duyệt điện thoại)
1. Tạo một repository GitHub mới.
2. Giải nén toàn bộ thư mục project này và tải các tệp/thư mục bên trong lên repository, giữ nguyên cấu trúc.
3. Đặt nhánh chính tên `main` nếu GitHub chưa tự tạo nhánh đó.
4. Mở thẻ **Actions** của repository. Workflow **Build Floating Tools APK** sẽ tự chạy sau khi push lên `main`; cũng có thể chọn workflow rồi bấm **Run workflow**.
5. Khi chạy xong, mở lần chạy mới nhất, kéo xuống **Artifacts**, tải `floating-tools-debug-apk` và giải nén để lấy `app-debug.apk`.
6. Chuyển APK về điện thoại Android và cài đặt. Android có thể hỏi cho phép cài ứng dụng từ nguồn bạn vừa dùng.

## Dùng ứng dụng
1. Mở Floating Tools.
2. Bấm **Bật cửa sổ nổi**.
3. Trong Cài đặt Android, bật quyền **Hiển thị trên ứng dụng khác** cho Floating Tools rồi quay lại ứng dụng.
4. Bấm **Bật cửa sổ nổi** lần nữa nếu dịch vụ chưa tự khởi động.
5. Chạm bong bóng `FT` để mở bảng. Chạm **Ẩn** để thu lại bong bóng; chọn **Tắt** để dừng dịch vụ.

## Ghi chú
- Một số hãng điện thoại có chế độ tiết kiệm pin riêng; hệ thống có thể dừng dịch vụ nền. Có thể cần cho phép ứng dụng chạy nền trong phần cài đặt pin của máy.
- Android 13 trở lên sẽ hỏi quyền thông báo khi bật tiện ích. Nên cho phép để dễ nhận biết dịch vụ đang chạy; nếu từ chối, tiện ích vẫn có thể khởi động nhưng thông báo có thể không hiện trong ngăn thông báo.
- Đây là bản debug APK tự cài, chưa phải bản phát hành Play Store.
