package com.example.floatingtools

/** Small arithmetic parser supporting +, -, *, /, parentheses and decimals. */
object ExpressionCalculator {
    fun calculate(source: String): Double {
        val parser = Parser(source.replace(" ", ""))
        val value = parser.expression()
        if (!parser.finished()) throw IllegalArgumentException("Biểu thức không hợp lệ")
        if (!value.isFinite()) throw IllegalArgumentException("Kết quả không hợp lệ")
        return value
    }

    private class Parser(private val input: String) {
        private var index = 0

        fun finished(): Boolean = index == input.length

        fun expression(): Double {
            var value = term()
            while (index < input.length) {
                when (input[index]) {
                    '+' -> { index++; value += term() }
                    '-' -> { index++; value -= term() }
                    else -> return value
                }
            }
            return value
        }

        private fun term(): Double {
            var value = factor()
            while (index < input.length) {
                when (input[index]) {
                    '*' -> { index++; value *= factor() }
                    '/' -> {
                        index++
                        val divisor = factor()
                        if (divisor == 0.0) throw IllegalArgumentException("Không thể chia cho 0")
                        value /= divisor
                    }
                    else -> return value
                }
            }
            return value
        }

        private fun factor(): Double {
            if (index >= input.length) throw IllegalArgumentException("Thiếu số")
            if (input[index] == '+') { index++; return factor() }
            if (input[index] == '-') { index++; return -factor() }
            if (input[index] == '(') {
                index++
                val value = expression()
                if (index >= input.length || input[index] != ')') throw IllegalArgumentException("Thiếu dấu )")
                index++
                return value
            }
            val start = index
            var dots = 0
            while (index < input.length && (input[index].isDigit() || input[index] == '.')) {
                if (input[index] == '.') dots++
                if (dots > 1) throw IllegalArgumentException("Số không hợp lệ")
                index++
            }
            if (start == index) throw IllegalArgumentException("Thiếu số")
            return input.substring(start, index).toDoubleOrNull()
                ?: throw IllegalArgumentException("Số không hợp lệ")
        }
    }
}
