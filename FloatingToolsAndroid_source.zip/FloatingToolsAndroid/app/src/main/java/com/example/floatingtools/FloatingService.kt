package com.example.floatingtools

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FloatingService : Service() {
    private lateinit var windowManager: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private lateinit var clockText: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val clockTick = object : Runnable {
        override fun run() {
            if (::clockText.isInitialized) {
                clockText.text = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
            }
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startAsForeground()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        showBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startAsForeground() {
        val openIntent = Intent(this, MainActivity::class.java)
        val pending = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        )
        val notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }.setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Floating Tools đang hoạt động")
            .setContentText("Chạm bong bóng FT để mở đồng hồ, ghi chú và máy tính.")
            .setContentIntent(pending)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Floating Tools", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Thông báo khi cửa sổ công cụ nổi đang hoạt động"
                }
            )
        }
    }

    private fun showBubble() {
        if (bubble != null) return
        val density = resources.displayMetrics.density
        val chip = TextView(this).apply {
            text = "FT"
            textSize = 16f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = shape(Color.rgb(111, 97, 255), (30 * density))
            elevation = 12 * density
        }
        val params = WindowManager.LayoutParams(
            (56 * density).toInt(), (56 * density).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (8 * density).toInt()
            y = (220 * density).toInt()
        }
        makeDraggable(chip, params, onTap = { togglePanel() })
        try {
            windowManager.addView(chip, params)
            bubble = chip
        } catch (_: Exception) {
            stopSelf()
        }
    }

    private fun togglePanel() {
        if (panel != null) {
            removePanel()
        } else {
            showPanel()
        }
    }

    private fun showPanel() {
        if (panel != null) return
        val density = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(14))
            background = shape(Color.rgb(27, 29, 43), dp(20).toFloat()).apply {
                setStroke(dp(1), Color.rgb(76, 78, 105))
            }
            elevation = 18 * density
        }

        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "FLOATING TOOLS"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(190, 183, 255))
            setPadding(0, dp(8), 0, dp(8))
        }
        titleRow.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        titleRow.addView(smallButton("Ẩn") { removePanel() })
        titleRow.addView(smallButton("Tắt") { stopSelf() }.apply {
            setTextColor(Color.rgb(255, 155, 155))
        })
        root.addView(titleRow)

        val timeLabel = text("ĐỒNG HỒ", 10, Color.LTGRAY, true)
        root.addView(timeLabel)
        clockText = text("--:--:--", 30, Color.WHITE, true).apply {
            setPadding(0, dp(2), 0, dp(10))
        }
        root.addView(clockText)
        handler.removeCallbacks(clockTick)
        handler.post(clockTick)

        root.addView(sectionDivider())
        root.addView(text("GHI CHÚ NHANH", 10, Color.rgb(190, 183, 255), true).apply {
            setPadding(0, dp(10), 0, dp(6))
        })
        val note = EditText(this).apply {
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            hint = "Viết ghi chú ở đây…"
            textSize = 13f
            minLines = 2
            maxLines = 4
            gravity = Gravity.TOP
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = shape(Color.rgb(42, 44, 61), dp(10).toFloat())
            setText(getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_NOTE, "") ?: "")
        }
        root.addView(note, LinearLayout.LayoutParams(-1, dp(82)))
        root.addView(smallButton("Lưu ghi chú") {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_NOTE, note.text.toString()).apply()
            Toast.makeText(this, "Đã lưu ghi chú trên thiết bị", Toast.LENGTH_SHORT).show()
        }.apply { setTextColor(Color.rgb(194, 187, 255)) })

        root.addView(sectionDivider())
        root.addView(text("MÁY TÍNH", 10, Color.rgb(190, 183, 255), true).apply {
            setPadding(0, dp(10), 0, dp(6))
        })
        val expression = EditText(this).apply {
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            hint = "Ví dụ: (12+8)*3"
            textSize = 14f
            singleLine = true
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = shape(Color.rgb(42, 44, 61), dp(10).toFloat())
        }
        root.addView(expression, LinearLayout.LayoutParams(-1, dp(46)))
        val calcRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val answer = text("Kết quả: —", 13, Color.WHITE, true)
        calcRow.addView(answer, LinearLayout.LayoutParams(0, -2, 1f))
        calcRow.addView(smallButton("Tính") {
            try {
                val value = ExpressionCalculator.calculate(expression.text.toString())
                val formatted = if (value % 1.0 == 0.0) value.toLong().toString() else String.format(Locale.getDefault(), "%.6f", value).trimEnd('0').trimEnd(',').trimEnd('.')
                answer.text = "Kết quả: $formatted"
            } catch (e: Exception) {
                answer.text = e.message ?: "Biểu thức chưa đúng"
            }
        })
        root.addView(calcRow)

        val params = WindowManager.LayoutParams(
            minOf((310 * density).toInt(), resources.displayMetrics.widthPixels - dp(20)),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(90)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        makePanelHeaderDraggable(title, params)
        try {
            windowManager.addView(root, params)
            panel = root
            panelParams = params
        } catch (_: Exception) {
            Toast.makeText(this, "Không thể mở cửa sổ nổi", Toast.LENGTH_SHORT).show()
        }
    }

    private fun makeDraggable(view: View, params: WindowManager.LayoutParams, onTap: () -> Unit) {
        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        var startX = 0
        var startY = 0
        var downRawX = 0f
        var downRawY = 0f
        var moved = false
        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    downRawX = event.rawX
                    downRawY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downRawX).toInt()
                    val dy = (event.rawY - downRawY).toInt()
                    if (kotlin.math.abs(dx) > touchSlop || kotlin.math.abs(dy) > touchSlop) moved = true
                    if (moved) {
                        params.x = startX + dx
                        params.y = startY + dy
                        try { windowManager.updateViewLayout(view, params) } catch (_: Exception) { }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onTap()
                    true
                }
                else -> true
            }
        }
    }

    private fun makePanelHeaderDraggable(view: View, params: WindowManager.LayoutParams) {
        var startX = 0
        var startY = 0
        var downX = 0f
        var downY = 0f
        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    downX = event.rawX; downY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - downX).toInt()
                    params.y = startY + (event.rawY - downY).toInt()
                    panel?.let { try { windowManager.updateViewLayout(it, params) } catch (_: Exception) { } }
                    true
                }
                else -> false
            }
        }
    }

    private fun removePanel() {
        panel?.let { try { windowManager.removeView(it) } catch (_: Exception) { } }
        panel = null
        panelParams = null
        handler.removeCallbacks(clockTick)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        removePanel()
        bubble?.let { try { windowManager.removeView(it) } catch (_: Exception) { } }
        bubble = null
        super.onDestroy()
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = value
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun smallButton(value: String, action: () -> Unit): TextView = TextView(this).apply {
        text = value
        textSize = 12f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setPadding(dp(10), dp(8), dp(10), dp(8))
        background = shape(Color.rgb(48, 50, 70), dp(9).toFloat())
        setOnClickListener { action() }
    }

    private fun sectionDivider(): View = View(this).apply {
        setBackgroundColor(Color.rgb(58, 60, 79))
        layoutParams = LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(8) }
    }

    private fun shape(color: Int, radius: Float): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        private const val CHANNEL_ID = "floating_tools_channel"
        private const val NOTIFICATION_ID = 401
        private const val PREFS = "floating_tools_prefs"
        private const val KEY_NOTE = "quick_note"
    }
}
