package com.example.floatingtools

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private var pendingStart = false
    private var notificationPromptHandled = false
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 17, 26)
        window.navigationBarColor = Color.rgb(16, 17, 26)
        setContentView(buildScreen())
        refreshStatus()
    }

    private fun buildScreen(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(24))
            setBackgroundColor(Color.rgb(16, 17, 26))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)

        content.addView(label("FLOATING TOOLS", 13, Color.rgb(164, 153, 255), true))
        content.addView(label("Tiện ích cửa sổ nổi", 28, Color.WHITE, true).apply {
            setPadding(0, dp(8), 0, dp(6))
        })
        content.addView(label("Đồng hồ · Ghi chú · Máy tính", 15, Color.LTGRAY, false))
        content.addView(space(24))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = rounded(Color.rgb(31, 33, 48), dp(18))
        }
        card.addView(label("CÁCH SỬ DỤNG", 12, Color.rgb(164, 153, 255), true))
        card.addView(label("1. Bật quyền Hiển thị trên ứng dụng khác.\n2. Chọn Bật cửa sổ nổi.\n3. Chạm bong bóng FT để mở bảng công cụ.\n4. Kéo bong bóng hoặc thanh tiêu đề để di chuyển.", 15, Color.WHITE, false).apply {
            setPadding(0, dp(12), 0, 0)
            setLineSpacing(dp(5).toFloat(), 1f)
        })
        content.addView(card)
        content.addView(space(18))

        statusText = label("Trạng thái: đang kiểm tra quyền…", 14, Color.LTGRAY, false)
        content.addView(statusText)
        content.addView(space(12))
        content.addView(actionButton("BẬT CỬA SỔ NỔI", Color.rgb(111, 97, 255)) { enableFloating() })
        content.addView(space(10))
        content.addView(actionButton("TẮT CỬA SỔ NỔI", Color.rgb(57, 60, 77)) {
            stopService(Intent(this, FloatingService::class.java))
            refreshStatus("Đã gửi lệnh tắt cửa sổ nổi.")
        })
        content.addView(space(22))
        content.addView(label("Lưu ý: ứng dụng cần quyền hiển thị trên ứng dụng khác. Khi bật công cụ nổi, Android sẽ hiện thông báo dịch vụ đang hoạt động. Ghi chú được lưu trên thiết bị.", 13, Color.GRAY, false))

        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        return root
    }

    private fun enableFloating() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            pendingStart = true
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivityForResult(intent, REQUEST_OVERLAY)
            return
        }
        startFloatingService()
    }

    private fun startFloatingService() {
        pendingStart = false
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED &&
            !notificationPromptHandled
        ) {
            notificationPromptHandled = true
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQUEST_NOTIFICATIONS)
            return
        }
        launchFloatingService()
    }

    private fun launchFloatingService() {
        val intent = Intent(this, FloatingService::class.java)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
            refreshStatus("Đã yêu cầu bật công cụ nổi.")
        } catch (e: Exception) {
            refreshStatus("Không thể bật dịch vụ: ${e.message ?: "lỗi hệ thống"}")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_NOTIFICATIONS) {
            // Notification permission is recommended but not required to start the visible utility.
            launchFloatingService()
        }
    }

    @Deprecated("Deprecated by Android; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_OVERLAY) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) {
                if (pendingStart) startFloatingService()
            } else {
                refreshStatus("Chưa cấp quyền hiển thị trên ứng dụng khác.")
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::statusText.isInitialized) refreshStatus()
    }

    private fun refreshStatus(message: String? = null) {
        if (!::statusText.isInitialized) return
        val permitted = Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)
        statusText.text = message ?: if (permitted) "Trạng thái: đã có quyền cửa sổ nổi." else "Trạng thái: chưa cấp quyền cửa sổ nổi."
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean): TextView = TextView(this).apply {
        this.text = text
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun actionButton(text: String, color: Int, action: () -> Unit): TextView = TextView(this).apply {
        this.text = text
        textSize = 14f
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        setTypeface(typeface, Typeface.BOLD)
        setPadding(dp(14), dp(15), dp(14), dp(15))
        background = rounded(color, dp(14))
        setOnClickListener { action() }
    }

    private fun space(height: Int): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun rounded(color: Int, radius: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object { private const val REQUEST_OVERLAY = 901; private const val REQUEST_NOTIFICATIONS = 902 }
}
